geoalchemy.dialect
=====================

.. automodule:: geoalchemy.dialect
   :members: